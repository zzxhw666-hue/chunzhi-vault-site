# 春枝数据看板

这个站点用于把本地 `http://localhost:4321` 的数据看板发布到 GitHub Pages。

访问方式：

```text
输入口令：chunzhi
```

## 当前数据

当前已同步本地 4321 看板数据快照：

```text
data/notes_metrics.json
```

即使 Supabase 快照表还没配置，网页也会先读取这份随站点发布的静态快照。

## Supabase 数据源

如果希望数据从 Supabase 读取：

1. 打开 Supabase 项目。
2. 进入 SQL Editor。
3. 运行 `supabase-schema.sql`。
4. 回到本地项目目录，执行：

```bash
node scripts/sync-supabase-dashboard.mjs
```

同步成功后，网页会优先读取 Supabase 的 `dashboard_snapshots/local-4321` 快照。

## GitHub Pages 发布

把这些文件上传到 GitHub 仓库根目录：

```text
index.html
styles.css
dashboard-app.js
supabase-config.js
supabase-schema.sql
README.md
data/notes_metrics.json
scripts/sync-supabase-dashboard.mjs
```

然后进入：

```text
Settings -> Pages
```

设置：

```text
Source: Deploy from a branch
Branch: main
Folder: /root
```

发布后访问：

```text
https://你的用户名.github.io/仓库名/
```

## 注意

`chunzhi` 是前端轻量口令，只适合普通分享和低风险看板，不适合保护敏感数据。
