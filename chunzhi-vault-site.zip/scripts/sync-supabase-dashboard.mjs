import { readFile } from "node:fs/promises";
import { resolve } from "node:path";

const root = resolve(import.meta.dirname, "..");
const configText = await readFile(resolve(root, "supabase-config.js"), "utf8");
const data = JSON.parse(await readFile(resolve(root, "data/notes_metrics.json"), "utf8"));

const url = configText.match(/supabaseUrl:\s*"([^"]+)"/)?.[1];
const anonKey = configText.match(/supabaseAnonKey:\s*"([^"]+)"/)?.[1];

if (!url || !anonKey) {
  throw new Error("supabase-config.js 缺少 supabaseUrl 或 supabaseAnonKey");
}

const response = await fetch(`${url.replace(/\/$/, "")}/rest/v1/dashboard_snapshots?on_conflict=slug`, {
  method: "POST",
  headers: {
    apikey: anonKey,
    Authorization: `Bearer ${anonKey}`,
    "Content-Type": "application/json",
    Prefer: "resolution=merge-duplicates,return=minimal",
  },
  body: JSON.stringify({
    slug: "local-4321",
    payload: data,
    updated_at: new Date().toISOString(),
  }),
});

if (!response.ok) {
  const text = await response.text();
  throw new Error(`同步失败：${response.status} ${text}`);
}

console.log(`已同步 ${data.rows?.length || 0} 条数据到 Supabase dashboard_snapshots/local-4321`);
