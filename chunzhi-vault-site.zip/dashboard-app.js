const ACCESS_CODE = "chunzhi";
const SESSION_KEY = "chunzhi-dashboard:unlocked";
const DASHBOARD_SLUG = "local-4321";
const config = window.CHUNZHI_VAULT_CONFIG || {};
let state = { rows: [], imports: [], updatedAt: "" };
let selectedFiles = [];
const multiFilterState = {
  account: new Set(),
  platform: new Set(),
};

const $ = (selector) => document.querySelector(selector);
const nf = new Intl.NumberFormat("zh-CN");
const platforms = ["小红书", "抖音", "视频号"];
const accountAliases = new Map();
const platformAliases = new Map([
  ["小红书", "小红书"],
  ["xhs", "小红书"],
  ["XHS", "小红书"],
  ["抖音", "抖音"],
  ["douyin", "抖音"],
  ["DY", "抖音"],
  ["视频号", "视频号"],
  ["微信视频号", "视频号"],
  ["shipinhao", "视频号"],
]);

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function toast(message) {
  const node = $("#toast");
  node.textContent = message;
  node.classList.add("show");
  window.setTimeout(() => node.classList.remove("show"), 2600);
}

async function api(path, options = {}) {
  const response = await fetch(path, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || "操作失败");
  return data;
}

function renderGate() {
  const unlocked = localStorage.getItem(SESSION_KEY) === "yes";
  $("#gateView").hidden = unlocked;
  $("#dashboardView").hidden = !unlocked;
  if (!unlocked) {
    window.setTimeout(() => $("#passcodeInput").focus(), 0);
  }
  return unlocked;
}

function formatNumber(value) {
  return nf.format(Math.round(Number(value || 0)));
}

function formatPercent(value) {
  return `${(Number(value || 0) * 100).toFixed(1)}%`;
}

function sum(rows, key) {
  return rows.reduce((total, row) => total + Number(row[key] || 0), 0);
}

function average(rows, key) {
  return rows.length ? rows.reduce((total, row) => total + Number(row[key] || 0), 0) / rows.length : 0;
}

function groupRows(rows, key) {
  return rows.reduce((map, row) => {
    const name = row[key] || "未分类";
    if (!map.has(name)) map.set(name, []);
    map.get(name).push(row);
    return map;
  }, new Map());
}

function summarize(rows, key) {
  return [...groupRows(rows, key).entries()]
    .map(([name, items]) => ({
      name,
      count: items.length,
      exposure: sum(items, "exposure"),
      views: sum(items, "views"),
      interactions: sum(items, "interactions"),
      followers: sum(items, "followers"),
      coverCtr: average(items, "coverCtr"),
    }))
    .sort((a, b) => b.views - a.views || b.exposure - a.exposure);
}

function normalizeAccountName(value) {
  const raw = String(value || "").trim();
  const text = stripDateSuffix(raw);
  return accountAliases.get(raw) || accountAliases.get(text) || text;
}

function normalizePlatformName(value) {
  const text = String(value || "").trim();
  return platformAliases.get(text) || "小红书";
}

function stripPlatformSuffix(value) {
  return String(value || "")
    .trim()
    .replace(/\s*(?:小红书|抖音|视频号|微信视频号|xhs|douyin|DY|shipinhao)$/iu, "")
    .trim();
}

function stripDateSuffix(value) {
  return stripPlatformSuffix(
    stripPlatformSuffix(String(value || "").trim().replace(/[()（）]/g, ""))
    .replace(/[+＋]\s*(?:20\d{2}[-_.年]?)?\d{1,2}[-_.月]\d{1,2}日?$/u, "")
    .replace(/(?:^|[-_\s])20\d{2}[-_.年]?\d{1,2}[-_.月]?\d{1,2}日?$/u, "")
    .replace(/(?:^|[-_\s])\d{8}$/u, "")
    .replace(/\s*(?:20\d{2})?[._-]\d{1,2}[._-]\d{1,2}$/u, "")
    .replace(/\s*\d{1,2}[._-]\d{1,2}$/u, "")
    .replace(/\s*(?:20\d{2}年)?\d{1,2}月\d{1,2}日?$/u, "")
    .replace(/[-_\s+＋]+$/u, "")
  ).trim();
}

function guessAccountName(fileName) {
  const base = fileName
    .replace(/\.(xlsx|xls|csv)$/i, "")
    .replace(/[()（）]/g, "")
    .trim();
  const plusParts = base.split(/[+＋]/).map((part) => part.trim()).filter(Boolean);
  if (plusParts.length >= 2) return normalizeAccountName(plusParts[0]);
  const withoutDate = stripDateSuffix(base);
  if (withoutDate && withoutDate !== base) return normalizeAccountName(withoutDate);
  const simplified = base.replace(/^笔记列表明细表[-_\s]*/i, "").trim();
  return normalizeAccountName(base) || normalizeAccountName(simplified) || simplified || fileName.replace(/\.(xlsx|xls|csv)$/i, "");
}

function normalizedRows(rows) {
  return rows.map((row) => ({
    ...row,
    platform: normalizePlatformName(row.platform),
    account: normalizeAccountName(row.account),
  }));
}

function accountSort(a, b) {
  return a.localeCompare(b, "zh-CN");
}

function displayRangeLabel(range, day) {
  if (range === "all") return "全部数据";
  if (range === "day") return day ? day : "指定日期";
  return `近 ${range} 天`;
}

function updateDayField() {
  $("#dayField").classList.toggle("hidden", $("#rangeSelect").value !== "day");
}

function defaultDay() {
  const latest = state.rows.map((row) => row.publishedDate).filter(Boolean).sort().at(-1);
  return latest || dateKey(new Date());
}

function ensureDayValue() {
  if ($("#rangeSelect").value === "day" && !$("#dayFilter").value) {
    $("#dayFilter").value = defaultDay();
  }
}

function toDate(dateText) {
  if (!dateText) return null;
  const date = new Date(`${dateText}T00:00:00`);
  return Number.isNaN(date.getTime()) ? null : date;
}

function dateKey(date) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}

function getWindowStart(rangeValue) {
  if (rangeValue === "all" || rangeValue === "day") return null;
  const end = new Date();
  const start = new Date(end.getFullYear(), end.getMonth(), end.getDate());
  start.setDate(start.getDate() - Number(rangeValue) + 1);
  return start;
}

function currentFilters() {
  return {
    range: $("#rangeSelect").value,
    day: $("#dayFilter").value,
    accounts: [...multiFilterState.account],
    platforms: [...multiFilterState.platform],
    category: $("#categoryFilter").value,
    format: $("#formatFilter").value,
    search: $("#searchInput").value.trim().toLowerCase(),
  };
}

function filteredRows() {
  const filters = currentFilters();
  const start = getWindowStart(filters.range);
  const end = new Date();
  end.setHours(23, 59, 59, 999);
  return state.rows
    .filter((row) => {
      const published = toDate(row.publishedDate);
      if (filters.range === "day" && filters.day && row.publishedDate !== filters.day) return false;
      if (start && published && (published < start || published > end)) return false;
      if (filters.accounts.length && !filters.accounts.includes(row.account)) return false;
      if (filters.platforms.length && !filters.platforms.includes(row.platform)) return false;
      if (filters.category !== "all" && row.category !== filters.category) return false;
      if (filters.format !== "all" && row.format !== filters.format) return false;
      if (filters.search && !String(row.title || "").toLowerCase().includes(filters.search)) return false;
      return true;
    })
    .sort((a, b) => String(b.publishedAt).localeCompare(String(a.publishedAt)));
}

function renderOptions(selector, values, allLabel) {
  const node = $(selector);
  const current = node.value || "all";
  node.innerHTML = [
    `<option value="all">${allLabel}</option>`,
    ...values.map((value) => `<option value="${escapeHtml(value)}">${escapeHtml(value)}</option>`),
  ].join("");
  node.value = values.includes(current) ? current : "all";
}

function multiFilterLabel(selected, allLabel) {
  if (!selected.length) return allLabel;
  if (selected.length <= 2) return selected.join("、");
  return `${selected.slice(0, 2).join("、")}等 ${selected.length} 项`;
}

function renderMultiFilter(kind, values, allLabel) {
  const selected = multiFilterState[kind];
  const validValues = new Set(values);
  [...selected].forEach((value) => {
    if (!validValues.has(value)) selected.delete(value);
  });

  const selectedValues = [...selected];
  const button = $(`#${kind}FilterButton`);
  const menu = $(`#${kind}FilterMenu`);
  button.textContent = multiFilterLabel(selectedValues, allLabel);
  button.classList.toggle("has-selection", selectedValues.length > 0);

  menu.innerHTML = [
    `<label class="multi-option all-option">
      <input type="checkbox" data-multi-kind="${kind}" data-multi-all="true" ${selectedValues.length ? "" : "checked"} />
      <span>${escapeHtml(allLabel)}</span>
    </label>`,
    ...values.map(
      (value) => `
        <label class="multi-option">
          <input type="checkbox" data-multi-kind="${kind}" value="${escapeHtml(value)}" ${selected.has(value) ? "checked" : ""} />
          <span title="${escapeHtml(value)}">${escapeHtml(value)}</span>
        </label>
      `
    ),
  ].join("");
}

function renderFilters() {
  renderMultiFilter("account", [...new Set(state.rows.map((row) => row.account).filter(Boolean))].sort(accountSort), "全部账号");
  renderMultiFilter("platform", [...new Set([...platforms, ...state.rows.map((row) => row.platform).filter(Boolean)])], "全部平台");
  renderOptions("#categoryFilter", [...new Set(state.rows.map((row) => row.category).filter(Boolean))], "全部分类");
  renderOptions("#formatFilter", [...new Set(state.rows.map((row) => row.format).filter(Boolean))], "全部体裁");
}

function renderMetrics(rows) {
  const exposure = sum(rows, "exposure");
  const views = sum(rows, "views");
  const likes = sum(rows, "likes");
  const comments = sum(rows, "comments");
  const saves = sum(rows, "saves");
  const shares = sum(rows, "shares");
  const interactions = sum(rows, "interactions");
  const metrics = [
    ["笔记数", rows.length, "当前筛选范围"],
    ["总曝光", formatNumber(exposure), "Impressions"],
    ["总观看量", formatNumber(views), "Views"],
    ["封面点击率", formatPercent(average(rows, "coverCtr")), "平均值"],
    ["点赞", formatNumber(likes), "独立互动项"],
    ["评论", formatNumber(comments), "独立互动项"],
    ["收藏", formatNumber(saves), "独立互动项"],
    ["分享", formatNumber(shares), "独立互动项"],
    ["互动量", formatNumber(interactions), "赞评藏转等"],
    ["互动率", formatPercent(views ? interactions / views : 0), "互动量 / 观看量"],
  ];
  $("#metrics").innerHTML = metrics
    .map(
      ([label, value, hint], index) => `
        <div class="metric metric-${index}">
          <span>${label}</span>
          <strong>${value}</strong>
          <small>${hint}</small>
        </div>
      `
    )
    .join("");
}

function emptyChart(text = "暂无数据") {
  return `<div class="empty">${text}</div>`;
}

function renderLineChart(rows) {
  if (!rows.length) {
    $("#trendChart").innerHTML = emptyChart();
    return;
  }
  const grouped = new Map();
  rows.forEach((row) => {
    const key = row.publishedDate || "未记录";
    if (!grouped.has(key)) grouped.set(key, { date: key, exposure: 0, views: 0 });
    grouped.get(key).exposure += Number(row.exposure || 0);
    grouped.get(key).views += Number(row.views || 0);
  });
  const data = [...grouped.values()].sort((a, b) => a.date.localeCompare(b.date));
  const width = 820;
  const height = 260;
  const pad = { top: 18, right: 22, bottom: 42, left: 58 };
  const maxValue = Math.max(1, ...data.flatMap((item) => [item.exposure, item.views]));
  const x = (index) => pad.left + (data.length === 1 ? 0 : (index * (width - pad.left - pad.right)) / (data.length - 1));
  const y = (value) => pad.top + (1 - value / maxValue) * (height - pad.top - pad.bottom);
  const line = (key) => data.map((item, index) => `${x(index)},${y(item[key])}`).join(" ");
  const grid = [0, 0.25, 0.5, 0.75, 1]
    .map((ratio) => {
      const gy = pad.top + ratio * (height - pad.top - pad.bottom);
      const label = formatNumber(maxValue * (1 - ratio));
      return `<line x1="${pad.left}" y1="${gy}" x2="${width - pad.right}" y2="${gy}" class="grid-line" />
        <text x="${pad.left - 8}" y="${gy + 4}" text-anchor="end" class="axis-label">${label}</text>`;
    })
    .join("");
  const labels = data
    .map((item, index) => {
      if (data.length > 10 && index % Math.ceil(data.length / 8) !== 0 && index !== data.length - 1) return "";
      return `<text x="${x(index)}" y="${height - 14}" text-anchor="middle" class="axis-label">${item.date.slice(5)}</text>`;
    })
    .join("");
  $("#trendChart").innerHTML = `
    <svg viewBox="0 0 ${width} ${height}" role="img" aria-label="每日趋势图">
      ${grid}
      <polyline points="${line("exposure")}" class="line exposure" />
      <polyline points="${line("views")}" class="line views" />
      ${data
        .map(
          (item, index) => `
          <circle cx="${x(index)}" cy="${y(item.exposure)}" r="3" class="point exposure-point" />
          <circle cx="${x(index)}" cy="${y(item.views)}" r="3" class="point views-point" />
        `
        )
        .join("")}
      ${labels}
    </svg>
    <div class="legend">
      <span><i class="dot" style="background:#2563eb"></i>曝光</span>
      <span><i class="dot" style="background:#16a34a"></i>观看</span>
    </div>
  `;
}

function renderBars(selector, items, valueKey, color = "var(--blue)") {
  if (!items.length) {
    $(selector).innerHTML = emptyChart();
    return;
  }
  const max = Math.max(1, ...items.map((item) => item[valueKey]));
  $(selector).innerHTML = items
    .slice(0, 10)
    .map(
      (item) => `
        <div class="bar-row">
          <div class="bar-label" title="${escapeHtml(item.name)}">${escapeHtml(item.name)}</div>
          <div class="bar-track"><div class="bar-fill" style="width:${Math.max(2, (item[valueKey] / max) * 100)}%;background:${color}"></div></div>
          <strong>${formatNumber(item[valueKey])}</strong>
        </div>
      `
    )
    .join("");
}

function renderTopNotes(rows) {
  const top = [...rows].sort((a, b) => Number(b.views || 0) - Number(a.views || 0)).slice(0, 8);
  $("#topNotes").innerHTML = top.length
    ? top
        .map(
          (row, index) => `
            <div class="top-item">
              <div class="rank">${index + 1}</div>
              <div>
                <div class="top-title" title="${escapeHtml(row.title)}">${escapeHtml(row.title)}</div>
                <div class="top-meta">${escapeHtml(row.platform)}｜${escapeHtml(row.account)}｜${escapeHtml(row.category)}｜${escapeHtml(row.publishedDate)}</div>
              </div>
              <div class="top-value">${formatNumber(row.views)}</div>
            </div>
          `
        )
        .join("")
    : emptyChart();
}

function renderTable(rows) {
  $("#tableCount").textContent = `${rows.length} 条`;
  $("#detailTable").innerHTML = rows
    .slice(0, 200)
    .map(
      (row) => `
        <tr>
          <td>${escapeHtml(row.publishedAt)}</td>
          <td>${escapeHtml(row.platform)}</td>
          <td>${escapeHtml(row.account)}</td>
          <td>${escapeHtml(row.category)}</td>
          <td title="${escapeHtml(row.title)}">${escapeHtml(row.title)}</td>
          <td>${escapeHtml(row.format)}</td>
          <td>${formatNumber(row.exposure)}</td>
          <td>${formatNumber(row.views)}</td>
          <td>${formatPercent(row.coverCtr)}</td>
          <td>${formatNumber(row.likes)}</td>
          <td>${formatNumber(row.comments)}</td>
          <td>${formatNumber(row.saves)}</td>
          <td>${formatNumber(row.shares)}</td>
          <td>${formatNumber(row.interactions)}</td>
          <td>${formatPercent(row.interactionRate)}</td>
          <td>${formatNumber(row.followers)}</td>
        </tr>
      `
    )
    .join("");
}

function renderWindowLabel() {
  const filters = currentFilters();
  $("#activeWindow").textContent = displayRangeLabel(filters.range, filters.day);
}

function renderLastUpdated() {
  const imported = state.imports?.[0];
  const updated = state.updatedAt ? new Date(state.updatedAt).toLocaleString("zh-CN") : "暂无";
  $("#lastUpdated").innerHTML = imported
    ? `最近更新：${updated}<br />最近导入：${escapeHtml(imported.account)}，${imported.rows} 条`
    : `最近更新：${updated}`;
}

function renderImportHistory() {
  const imports = state.imports || [];
  $("#importHistory").innerHTML = imports.length
    ? imports
        .slice(0, 8)
        .map((item) => {
          const time = item.importedAt ? new Date(item.importedAt).toLocaleString("zh-CN") : "";
          const status = item.rolledBackAt ? "已回退" : `${item.added || 0} 新增 / ${item.updated || 0} 更新`;
          return `
            <div class="import-item">
              <div>
                <strong>${escapeHtml(item.platform || "小红书")}｜${escapeHtml(item.account)}</strong>
                <span>${escapeHtml(item.fileName || "")}</span>
                <small>${escapeHtml(time)}｜${escapeHtml(status)}</small>
              </div>
              <span class="rollback-state">${item.rolledBackAt ? "已回退" : "已同步"}</span>
            </div>
          `;
        })
        .join("")
    : `<div class="empty-mini">暂无导入记录</div>`;
}

function renderDashboard() {
  updateDayField();
  ensureDayValue();
  const rows = filteredRows();
  renderWindowLabel();
  renderMetrics(rows);
  renderLineChart(rows);
  renderBars("#accountChart", summarize(rows, "account"), "views", "var(--blue)");
  renderBars("#categoryChart", summarize(rows, "category"), "views", "var(--teal)");
  renderTopNotes(rows);
  renderTable(rows);
  renderLastUpdated();
  renderImportHistory();
}

function renderFileList() {
  $("#importButton").disabled = selectedFiles.length === 0;
  $("#fileList").innerHTML = selectedFiles
    .map(
      (file, index) => `
        <div class="file-row">
          <span class="file-name">${escapeHtml(file.name)}</span>
          <select data-platform-index="${index}">
            ${platforms.map((platform) => `<option value="${platform}">${platform}</option>`).join("")}
          </select>
          <input data-account-index="${index}" value="${escapeHtml(guessAccountName(file.name))}" placeholder="账号名称" />
        </div>
      `
    )
    .join("");
}

function readFileBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result).split(",").pop());
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}

async function importSelectedFiles() {
  const inputs = [...document.querySelectorAll("[data-account-index]")];
  const platformInputs = [...document.querySelectorAll("[data-platform-index]")];
  const files = await Promise.all(
    selectedFiles.map(async (file, index) => ({
      name: file.name,
      account: normalizeAccountName(inputs[index]?.value?.trim() || guessAccountName(file.name)),
      platform: normalizePlatformName(platformInputs[index]?.value),
      base64: await readFileBase64(file),
    }))
  );
  const result = await api("/api/import", {
    method: "POST",
    body: JSON.stringify({ files }),
  });
  state = result;
  state.rows = normalizedRows(state.rows || []);
  state.imports = (state.imports || []).map((item) => ({
    ...item,
    platform: normalizePlatformName(item.platform),
    account: normalizeAccountName(item.account),
  }));
  selectedFiles = [];
  $("#fileInput").value = "";
  renderFileList();
  renderFilters();
  renderDashboard();
  const added = result.importResults.reduce((total, item) => total + item.added, 0);
  const updated = result.importResults.reduce((total, item) => total + item.updated, 0);
  toast(`导入完成：新增 ${added} 条，更新 ${updated} 条`);
}

async function resetData() {
  if (!window.confirm("确定清空本地已导入的数据吗？")) return;
  state = await api("/api/reset", { method: "POST", body: "{}" });
  state.rows = [];
  state.imports = [];
  renderFilters();
  renderDashboard();
  toast("本地数据已清空");
}

async function rollbackImport(importId) {
  if (!window.confirm("确定回退这次导入吗？这会撤销该表格带来的新增/更新。")) return;
  state = await api("/api/rollback", {
    method: "POST",
    body: JSON.stringify({ id: importId }),
  });
  state.rows = normalizedRows(state.rows || []);
  state.imports = (state.imports || []).map((item) => ({
    ...item,
    platform: normalizePlatformName(item.platform),
    account: normalizeAccountName(item.account),
  }));
  renderFilters();
  renderDashboard();
  toast("已回退这次导入");
}

async function loadState() {
  state = await loadPublishedState();
  state.rows = normalizedRows(state.rows || []);
  state.imports = (state.imports || []).map((item) => ({
    ...item,
    platform: normalizePlatformName(item.platform),
    account: normalizeAccountName(item.account),
  }));
  renderFilters();
  renderDashboard();
}

async function loadPublishedState() {
  const supabaseState = await loadSupabaseSnapshot().catch(() => null);
  if (supabaseState) {
    $("#dataSourceText").textContent = `数据源：Supabase｜${supabaseState.rows?.length || 0} 条`;
    return supabaseState;
  }

  const staticState = await api("./data/notes_metrics.json");
  $("#dataSourceText").textContent = `数据源：随站点发布的本地快照｜${staticState.rows?.length || 0} 条`;
  return staticState;
}

async function loadSupabaseSnapshot() {
  if (!config.supabaseUrl || !config.supabaseAnonKey) return null;
  const baseUrl = config.supabaseUrl.replace(/\/$/, "");
  const url = `${baseUrl}/rest/v1/dashboard_snapshots?slug=eq.${encodeURIComponent(DASHBOARD_SLUG)}&select=payload,updated_at&limit=1`;
  const data = await api(url, {
    headers: {
      apikey: config.supabaseAnonKey,
      Authorization: `Bearer ${config.supabaseAnonKey}`,
      "Content-Type": "application/json",
    },
  });
  const snapshot = data?.[0]?.payload;
  return snapshot?.rows ? snapshot : null;
}

function exportCsv() {
  const rows = filteredRows();
  const csv = toCsv(rows);
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `chunzhi-dashboard-${new Date().toISOString().slice(0, 10)}.csv`;
  link.click();
  URL.revokeObjectURL(url);
}

function csvEscape(value) {
  const text = value == null ? "" : String(value);
  return `"${text.replaceAll('"', '""')}"`;
}

function toCsv(rows) {
  const headers = [
    "平台",
    "账号",
    "内容分类",
    "笔记标题",
    "首次发布时间",
    "发布日期",
    "发布月份",
    "体裁",
    "曝光",
    "观看量",
    "封面点击率",
    "点赞",
    "评论",
    "收藏",
    "涨粉",
    "分享",
    "人均观看时长",
    "弹幕",
    "互动量",
    "互动率",
    "观看/曝光",
    "来源文件",
  ];
  const fields = [
    "platform",
    "account",
    "category",
    "title",
    "publishedAt",
    "publishedDate",
    "publishedMonth",
    "format",
    "exposure",
    "views",
    "coverCtr",
    "likes",
    "comments",
    "saves",
    "followers",
    "shares",
    "avgWatchDuration",
    "danmaku",
    "interactions",
    "interactionRate",
    "viewRate",
    "sourceFile",
  ];
  return [headers.map(csvEscape).join(","), ...rows.map((row) => fields.map((field) => csvEscape(row[field])).join(","))].join("\n");
}

function bindEvents() {
  $("#gateForm").addEventListener("submit", (event) => {
    event.preventDefault();
    const code = $("#passcodeInput").value.trim();
    if (code !== ACCESS_CODE) {
      $("#gateMessage").textContent = "口令不正确。";
      $("#gateMessage").hidden = false;
      return;
    }
    localStorage.setItem(SESSION_KEY, "yes");
    $("#passcodeInput").value = "";
    $("#gateMessage").hidden = true;
    renderGate();
    loadState().catch((error) => toast(error.message));
  });
  $("#lockButton").addEventListener("click", () => {
    localStorage.removeItem(SESSION_KEY);
    renderGate();
  });
  $("#exportButton").addEventListener("click", exportCsv);
  $("#rangeSelect").addEventListener("change", () => {
    updateDayField();
    ensureDayValue();
    renderDashboard();
  });
  document.addEventListener("click", (event) => {
    const trigger = event.target.closest("[data-multi-trigger]");
    if (trigger) {
      const kind = trigger.dataset.multiTrigger;
      document.querySelectorAll(".multi-menu").forEach((menu) => {
        const open = menu.id === `${kind}FilterMenu` && menu.hidden;
        menu.hidden = !open;
        const button = $(`#${menu.id.replace("Menu", "Button")}`);
        if (button) button.setAttribute("aria-expanded", String(open));
      });
      return;
    }
    if (!event.target.closest(".multi-select")) {
      document.querySelectorAll(".multi-menu").forEach((menu) => {
        menu.hidden = true;
        const button = $(`#${menu.id.replace("Menu", "Button")}`);
        if (button) button.setAttribute("aria-expanded", "false");
      });
    }
  });
  document.addEventListener("change", (event) => {
    const input = event.target.closest("[data-multi-kind]");
    if (!input) return;
    const kind = input.dataset.multiKind;
    if (input.dataset.multiAll) {
      multiFilterState[kind].clear();
    } else if (input.checked) {
      multiFilterState[kind].add(input.value);
    } else {
      multiFilterState[kind].delete(input.value);
    }
    renderFilters();
    renderDashboard();
  });
  ["#dayFilter", "#categoryFilter", "#formatFilter", "#searchInput"].forEach((selector) => {
    $(selector).addEventListener("input", renderDashboard);
    $(selector).addEventListener("change", renderDashboard);
  });
}

bindEvents();
if (renderGate()) {
  loadState().catch((error) => toast(error.message));
}
