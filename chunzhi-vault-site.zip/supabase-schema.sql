create table if not exists public.dashboard_snapshots (
  slug text primary key,
  payload jsonb not null,
  updated_at timestamptz not null default now()
);

alter table public.dashboard_snapshots enable row level security;

drop policy if exists "Anyone can read dashboard snapshots" on public.dashboard_snapshots;
create policy "Anyone can read dashboard snapshots"
on public.dashboard_snapshots
for select
to anon
using (true);

drop policy if exists "Anyone can insert dashboard snapshots" on public.dashboard_snapshots;
create policy "Anyone can insert dashboard snapshots"
on public.dashboard_snapshots
for insert
to anon
with check (true);

drop policy if exists "Anyone can update dashboard snapshots" on public.dashboard_snapshots;
create policy "Anyone can update dashboard snapshots"
on public.dashboard_snapshots
for update
to anon
using (true)
with check (true);
